package com.example.practica2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
